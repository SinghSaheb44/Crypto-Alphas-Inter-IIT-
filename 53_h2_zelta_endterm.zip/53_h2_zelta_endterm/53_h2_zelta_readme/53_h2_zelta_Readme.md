**Readme**

This document is a Readme. Which briefs about the files containing in the zip folder.

**53\_h2\_zelta\_optimisers** \- is a file containing the list of optimisers we tried including bayesian optimiser,genetic optimiser,grid search etc.  
**Requirements** \- Numpy,Pandas,Scipy,Sklearn,deap.

**53\_h2\_zelta\_filters** \- is a file containing the various filters such as Kalman filters,savitzky golay etc.  
**Requirements** \- Numpy,Pandas,Scipy,pykalman.

**53\_h2\_zelta\_Ml\_approaches** \- Patch TST was used to predict the closing price,SMA, and EMA , Arima and LSTM, XGboosr were used to create strategies.  
**Requirements**\-Pandas,Numpy,SKlearn,pmdarima,keras,tqdm,XGboost,talib,matplotlib,pandas\_ta,pprint,torch.  
**53\_h2\_zelta\_Indicator\_base\_trading\_Strategies \-** Here we have 4 strategies btc\_main\_1,2 and eth\_main\_1,2.  
**Requirements-** Pandas,Numpy,talib,matplotlib.Pandas\_ta,pprint,pykalman,datetime,arch,scipy,statsmodels

